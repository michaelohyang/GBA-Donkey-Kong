Michael Oh-Yang
Kong's Jungle


Game: You play as Donkey Kong and try manuveur around the obstacles to reach the goal

Win Condition: Reach the white box without touching the wood

Lose Condition: Touch the wood


Control:

Up Arrow - move up
Down Arrow - move down
Left Arrow - move left
Right Arrow - move right
Backspace - restart game (after winning or losing)
Z button - press to proceed to the game