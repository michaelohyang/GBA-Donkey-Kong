/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize 240x160 jungle jungle.jpg 
 * Time-stamp: Thursday 04/02/2020, 20:01:44
 * 
 * Image Information
 * -----------------
 * jungle.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef JUNGLE_H
#define JUNGLE_H

extern const unsigned short jungle[38400];
#define JUNGLE_SIZE 76800
#define JUNGLE_LENGTH 38400
#define JUNGLE_WIDTH 240
#define JUNGLE_HEIGHT 160

#endif

