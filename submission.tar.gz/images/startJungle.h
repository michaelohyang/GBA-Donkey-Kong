/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize 240x160 startJungle startJungle.jpg 
 * Time-stamp: Thursday 04/02/2020, 21:43:38
 * 
 * Image Information
 * -----------------
 * startJungle.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTJUNGLE_H
#define STARTJUNGLE_H

extern const unsigned short startJungle[38400];
#define STARTJUNGLE_SIZE 76800
#define STARTJUNGLE_LENGTH 38400
#define STARTJUNGLE_WIDTH 240
#define STARTJUNGLE_HEIGHT 160

#endif

