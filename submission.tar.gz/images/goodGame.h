/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize 240x160 goodGame goodGame.jpg 
 * Time-stamp: Thursday 04/02/2020, 20:02:05
 * 
 * Image Information
 * -----------------
 * goodGame.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GOODGAME_H
#define GOODGAME_H

extern const unsigned short goodGame[38400];
#define GOODGAME_SIZE 76800
#define GOODGAME_LENGTH 38400
#define GOODGAME_WIDTH 240
#define GOODGAME_HEIGHT 160

#endif

