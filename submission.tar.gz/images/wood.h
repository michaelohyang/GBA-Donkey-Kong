/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize 40x10 wood wood.jpg 
 * Time-stamp: Thursday 04/02/2020, 20:20:45
 * 
 * Image Information
 * -----------------
 * wood.jpg 40@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WOOD_H
#define WOOD_H

extern const unsigned short wood[400];
#define WOOD_SIZE 800
#define WOOD_LENGTH 400
#define WOOD_WIDTH 40
#define WOOD_HEIGHT 10

#endif

